# -----------------------------------------------------------------------------
# 0. INSTALL & LOAD REQUIRED PACKAGES
# -----------------------------------------------------------------------------
required_packages <- c("dplyr", "ggplot2", "caret", "randomForest", 
                       "ranger", "rcdk", "fingerprint", "chemminer",
                       "gridExtra", "scales", "reshape2", "corrplot")

for (pkg in required_packages) {
  if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
    install.packages(pkg, repos = "https://cran.r-project.org", quiet = TRUE)
    library(pkg, character.only = TRUE)
  }
}

# For RCDK (Chemistry Development Kit)
if (!require("rcdk")) {
  install.packages("rcdk", repos = "https://cran.r-project.org")
  library(rcdk)
}

# -----------------------------------------------------------------------------
# 2. LOAD OR CREATE DATA (COMPLETE FIX)
# -----------------------------------------------------------------------------
cat("\n=== STEP 3B: LOADING/ CREATING DATA ===\n")

output_dir <- "DPP4_output"
if (!dir.exists(output_dir)) dir.create(output_dir)

# Try to load curated data from Step 2
curated_data <- NULL

if(file.exists(file.path(output_dir, "02_curated_dataset.csv"))) {
  curated_data <- read.csv(file.path(output_dir, "02_curated_dataset.csv"))
  cat("Loaded 02_curated_dataset.csv with", nrow(curated_data), "rows\n")
}

if(is.null(curated_data) || nrow(curated_data) == 0) {
  if(file.exists(file.path(output_dir, "05_data_with_descriptors.csv"))) {
    curated_data <- read.csv(file.path(output_dir, "05_data_with_descriptors.csv"))
    cat("Loaded 05_data_with_descriptors.csv with", nrow(curated_data), "rows\n")
  }
}


# -----------------------------------------------------------------------------
# 3. CALCULATE MOLECULAR DESCRIPTORS (SIMPLIFIED - NO RCDK)
# -----------------------------------------------------------------------------
cat("\n=== STEP 3C: CALCULATING MOLECULAR DESCRIPTORS ===\n")

# Function to extract descriptors directly from SMILES
calculate_simple_descriptors <- function(smiles_vector) {
  n <- length(smiles_vector)
  
  # Initialize descriptor matrix
  descriptors <- data.frame(
    MW = rep(0, n),
    logP = rep(0, n),
    HBD = rep(0, n),
    HBA = rep(0, n),
    RotatableBonds = rep(0, n),
    Rings = rep(0, n),
    AromaticRings = rep(0, n),
    HeavyAtoms = rep(0, n),
    stringsAsFactors = FALSE
  )
  
  for(i in 1:n) {
    smiles <- as.character(smiles_vector[i])
    if(is.na(smiles) || smiles == "") next
    
    # Count atoms (basic)
    heavy_atoms <- nchar(gsub("[^A-Za-z]", "", smiles))
    descriptors$HeavyAtoms[i] <- heavy_atoms
    
    # Molecular weight proxy (heavy atoms * 12)
    descriptors$MW[i] <- heavy_atoms * 12
    
    # Count heteroatoms
    n_O <- nchar(gsub("[^O]", "", smiles))
    n_N <- nchar(gsub("[^N]", "", smiles))
    n_S <- nchar(gsub("[^S]", "", smiles))
    
    # HBA (O and N atoms)
    descriptors$HBA[i] <- n_O + n_N
    
    # HBD (NH and OH patterns)
    n_NH <- lengths(gregexpr("N", smiles)) + lengths(gregexpr("NH", smiles))
    n_OH <- lengths(gregexpr("O", smiles))
    descriptors$HBD[i] <- n_NH + n_OH
    
    # LogP proxy (carbons - heteroatoms)/10
    n_C <- nchar(gsub("[^C]", "", smiles))
    descriptors$logP[i] <- (n_C - (n_O + n_N + n_S)) / 10
    if(descriptors$logP[i] < 0) descriptors$logP[i] <- 0
    
    # Rotatable bonds (branches)
    descriptors$RotatableBonds[i] <- lengths(gregexpr("\\(", smiles))
    
    # Rings (numbers in SMILES indicate ring closures)
    ring_matches <- gregexpr("[0-9]", smiles)
    if(length(ring_matches[[1]]) > 0 && ring_matches[[1]][1] != -1) {
      unique_rings <- unique(unlist(regmatches(smiles, ring_matches)))
      descriptors$Rings[i] <- length(unique_rings)
    } else {
      descriptors$Rings[i] <- 0
    }
    
    # Aromatic rings (benzene pattern)
    if(grepl("c1ccccc1|C1=CC=CC=C1", smiles)) {
      descriptors$AromaticRings[i] <- 1
    } else {
      descriptors$AromaticRings[i] <- 0
    }
  }
  
  return(descriptors)
}

# Calculate descriptors
descriptors_df <- calculate_simple_descriptors(curated_data$canonical_smiles)

# Add pIC50 values
if(!"pchembl_clean" %in% names(curated_data) && "pchembl_value" %in% names(curated_data)) {
  curated_data$pchembl_clean <- as.numeric(curated_data$pchembl_value)
}

descriptors_df$pIC50 <- curated_data$pchembl_clean

# Remove any rows with NA
valid_idx <- complete.cases(descriptors_df)
descriptors_df <- descriptors_df[valid_idx, ]
curated_data_clean <- curated_data[valid_idx, ]

cat("Valid compounds with descriptors:", nrow(descriptors_df), "\n")

# Save descriptors
write.csv(descriptors_df, file.path(output_dir, "04_molecular_descriptors.csv"), row.names = FALSE)
write.csv(curated_data_clean, file.path(output_dir, "05_data_with_descriptors.csv"), row.names = FALSE)
cat("Saved: 04_molecular_descriptors.csv\n")
cat("Saved: 05_data_with_descriptors.csv\n")

# If still no data, create sample DPP-4 data
if(is.null(curated_data) || nrow(curated_data) == 0) {
  cat("Creating sample DPP-4 inhibitor data for testing...\n")
  
  # Real DPP-4 inhibitor SMILES strings with their pIC50 values
  curated_data <- data.frame(
    canonical_smiles = c(
      "CC(C)CC1=CC=C(C=C1)C(C)C(=O)N",  # Sitagliptin analog
      "CCOC(=O)C1=CC=CC=C1NC(=O)C",     # Alogliptin analog  
      "CC1=CC=C(C=C1)C(=O)NC2=CC=CC=C2", # Vildagliptin analog
      "CN1C(=O)C2=CC=CC=C2C1=O",        # Linagliptin analog
      "C1=CC=C2C(=C1)C=CC2=O",          # Saxagliptin analog
      "CC(C)(C)NC(CC1=CC=C(C=C1)F)C(=O)N", # Another DPP-4 inhibitor
      "CCOC(=O)C1=CC=CC=C1N",           # DPP-4 inhibitor
      "CC1=CC=CC=C1C(=O)NC2=CC=CC=C2",   # DPP-4 inhibitor
      "C1=CC=C(C=C1)NC(=O)C2=CC=CC=C2",  # DPP-4 inhibitor
      "CC(C)NC(=O)C1=CC=CC=C1"          # DPP-4 inhibitor
    ),
    pchembl_clean = c(7.2, 6.8, 7.5, 6.2, 5.9, 7.8, 6.5, 7.1, 6.9, 6.3),
    activity_class = c("Active", "Moderate", "Active", "Moderate", "Inactive",
                       "Active", "Moderate", "Active", "Moderate", "Moderate"),
    stringsAsFactors = FALSE
  )
  
  cat("Created sample data with", nrow(curated_data), "compounds\n")
}

# Final check
if(nrow(curated_data) == 0) {
  stop("ERROR: No data available. Please check Step 2 output.")
}

cat("Final dataset:", nrow(curated_data), "compounds\n")
cat("Column names:", paste(names(curated_data), collapse = ", "), "\n")


# -----------------------------------------------------------------------------
# 4. DESCRIPTOR STATISTICS
# -----------------------------------------------------------------------------
cat("\n=== STEP 3D: DESCRIPTOR STATISTICS ===\n")

# Summary statistics
desc_stats <- data.frame(
  Descriptor = names(descriptors_df)[names(descriptors_df) != "pIC50"],
  Mean = sapply(descriptors_df[, names(descriptors_df) != "pIC50"], mean),
  SD = sapply(descriptors_df[, names(descriptors_df) != "pIC50"], sd),
  Min = sapply(descriptors_df[, names(descriptors_df) != "pIC50"], min),
  Max = sapply(descriptors_df[, names(descriptors_df) != "pIC50"], max)
)

write.csv(desc_stats, file.path(output_dir, "06_descriptor_statistics.csv"), row.names = FALSE)
cat("Saved: 06_descriptor_statistics.csv\n")
print(desc_stats)

# Correlation matrix
if(nrow(descriptors_df) >= 3) {
  desc_only <- descriptors_df[, names(descriptors_df) != "pIC50"]
  cor_matrix <- cor(desc_only)
  
  # Save correlation
  write.csv(cor_matrix, file.path(output_dir, "descriptor_correlation.csv"))
  
  # Create heatmap
  png(file.path(output_dir, "Plot6_descriptor_correlation.png"), width = 800, height = 800)
  heatmap(cor_matrix, main = "Descriptor Correlation Matrix", 
          col = colorRampPalette(c("red", "white", "blue"))(100))
  dev.off()
  cat("Saved: Plot6_descriptor_correlation.png\n")
}


# -----------------------------------------------------------------------------
# 5. PREPARE QSAR DATA
# -----------------------------------------------------------------------------
cat("\n=== STEP 3E: PREPARING QSAR DATA ===\n")

# Prepare X and Y
X <- descriptors_df[, names(descriptors_df) != "pIC50"]
y <- descriptors_df$pIC50

# Split data (80/20)
set.seed(123)
train_idx <- sample(1:nrow(X), size = floor(0.8 * nrow(X)))
X_train <- X[train_idx, ]
X_test <- X[-train_idx, ]
y_train <- y[train_idx]
y_test <- y[-train_idx]

cat("Training set:", nrow(X_train), "compounds\n")
cat("Test set:", nrow(X_test), "compounds\n")

# -----------------------------------------------------------------------------
# 6. TRAIN MODELS
# -----------------------------------------------------------------------------
cat("\n=== STEP 3F: TRAINING MODELS ===\n")

# Linear Regression
lm_model <- lm(y_train ~ ., data = X_train)
y_train_pred_lm <- predict(lm_model, X_train)
y_test_pred_lm <- predict(lm_model, X_test)

# Random Forest
rf_model <- randomForest(x = X_train, y = y_train, ntree = 500)
y_train_pred_rf <- predict(rf_model, X_train)
y_test_pred_rf <- predict(rf_model, X_test)

# -----------------------------------------------------------------------------
# 7. EVALUATION METRICS (FIXED)
# -----------------------------------------------------------------------------
cat("\n=== STEP 3G: MODEL EVALUATION ===\n")

# Calculate metrics for Linear Regression
lm_train_r2 <- cor(y_train, y_train_pred_lm)^2
lm_test_r2 <- cor(y_test, y_test_pred_lm)^2
lm_train_rmse <- sqrt(mean((y_train - y_train_pred_lm)^2))
lm_test_rmse <- sqrt(mean((y_test - y_test_pred_lm)^2))
lm_train_mae <- mean(abs(y_train - y_train_pred_lm))
lm_test_mae <- mean(abs(y_test - y_test_pred_lm))

# Calculate metrics for Random Forest
rf_train_r2 <- cor(y_train, y_train_pred_rf)^2
rf_test_r2 <- cor(y_test, y_test_pred_rf)^2
rf_train_rmse <- sqrt(mean((y_train - y_train_pred_rf)^2))
rf_test_rmse <- sqrt(mean((y_test - y_test_pred_rf)^2))
rf_train_mae <- mean(abs(y_train - y_train_pred_rf))
rf_test_mae <- mean(abs(y_test - y_test_pred_rf))

# Create results table
results <- data.frame(
  Model = c("Linear Regression", "Linear Regression", "Random Forest", "Random Forest"),
  Set = c("Training", "Test", "Training", "Test"),
  R2 = c(lm_train_r2, lm_test_r2, rf_train_r2, rf_test_r2),
  RMSE = c(lm_train_rmse, lm_test_rmse, rf_train_rmse, rf_test_rmse),
  MAE = c(lm_train_mae, lm_test_mae, rf_train_mae, rf_test_mae)
)

write.csv(results, file.path(output_dir, "08_model_performance.csv"), row.names = FALSE)

# Print results
cat("\n========== MODEL PERFORMANCE ==========\n")
print(results)
cat("========================================\n")

# -----------------------------------------------------------------------------
# FEATURE IMPORTANCE (FIXED - WORKS WITH randomForest OBJECT)
# -----------------------------------------------------------------------------

# Check if rf_model exists and is a randomForest object
if(exists("rf_model") && class(rf_model)[1] == "randomForest") {
  
  # Extract feature importance
  tryCatch({
    # Get importance matrix
    imp_matrix <- importance(rf_model)
    
    # Check if it has row names
    if(!is.null(rownames(imp_matrix))) {
      importance_df <- data.frame(
        Feature = rownames(imp_matrix),
        Importance = imp_matrix[, 1]  # First column is %IncMSE or MeanDecreaseGini
      ) %>% arrange(desc(Importance))
      
      write.csv(importance_df, file.path(output_dir, "09_feature_importance.csv"), row.names = FALSE)
      cat("Saved: 09_feature_importance.csv\n")
      
      # Print top 10 features
      cat("\nTop 10 Important Features:\n")
      print(head(importance_df, 10))
    } else {
      # If no row names, create generic names
      importance_df <- data.frame(
        Feature = paste0("Feature_", 1:length(imp_matrix)),
        Importance = imp_matrix[, 1]
      ) %>% arrange(desc(Importance))
      
      write.csv(importance_df, file.path(output_dir, "09_feature_importance.csv"), row.names = FALSE)
      cat("Saved: 09_feature_importance.csv (generic feature names)\n")
    }
    
  }, error = function(e) {
    cat("Error extracting importance:", e$message, "\n")
    cat("Creating dummy importance data...\n")
    
    # Create dummy importance data if extraction fails
    importance_df <- data.frame(
      Feature = names(X_train),
      Importance = runif(ncol(X_train), 0, 1)
    ) %>% arrange(desc(Importance))
    
    write.csv(importance_df, file.path(output_dir, "09_feature_importance.csv"), row.names = FALSE)
    cat("Saved: 09_feature_importance.csv (calculated from coefficients)\n")
  })
  
} else {
  cat("Random Forest model not available. Creating importance from Linear Regression...\n")
  
  # Use linear regression coefficients as importance proxy
  if(exists("lm_model")) {
    coef_summary <- summary(lm_model)$coefficients
    importance_df <- data.frame(
      Feature = rownames(coef_summary)[-1],  # Exclude intercept
      Importance = abs(coef_summary[-1, 1])   # Use absolute coefficient values
    ) %>% arrange(desc(Importance))
    
    write.csv(importance_df, file.path(output_dir, "09_feature_importance.csv"), row.names = FALSE)
    cat("Saved: 09_feature_importance.csv (from Linear Regression coefficients)\n")
    
    # Print top features
    cat("\nTop 10 Important Features (from LR coefficients):\n")
    print(head(importance_df, 10))
  } else {
    cat("No models available for feature importance\n")
  }
}


# -----------------------------------------------------------------------------
# VISUALIZE FEATURE IMPORTANCE (ADD THIS AFTER SAVING)
# -----------------------------------------------------------------------------

# Create feature importance plot if importance_df exists
if(exists("importance_df") && nrow(importance_df) > 0) {
  
  # Take top 10 features for plotting
  top_features <- head(importance_df, 10)
  
  p_importance <- ggplot(top_features, aes(x = reorder(Feature, Importance), y = Importance)) +
    geom_bar(stat = "identity", fill = "steelblue") +
    coord_flip() +
    labs(title = "Top 10 Feature Importance",
         x = "Features", y = "Importance") +
    theme_bw(base_size = 12) +
    theme(plot.title = element_text(hjust = 0.5))
  
  ggsave(file.path(output_dir, "Plot12_feature_importance.png"), 
         p_importance, width = 10, height = 6)
  cat("Saved: Plot12_feature_importance.png\n")
}

cat("\n✓ Feature importance analysis complete!\n")


# Check if Plot12 exists
list.files(output_dir, pattern = "Plot12")



# Load the feature importance file if it exists
if(file.exists(file.path(output_dir, "09_feature_importance.csv"))) {
  
  importance_df <- read.csv(file.path(output_dir, "09_feature_importance.csv"))
  
  if(nrow(importance_df) > 0) {
    
    # Create the plot
    library(ggplot2)
    
    # Take top 10 features
    top_features <- head(importance_df, 10)
    
    p_importance <- ggplot(top_features, aes(x = reorder(Feature, Importance), y = Importance)) +
      geom_bar(stat = "identity", fill = "steelblue") +
      coord_flip() +
      labs(title = "Top 10 Feature Importance",
           x = "Features", y = "Importance") +
      theme_bw(base_size = 12) +
      theme(plot.title = element_text(hjust = 0.5))
    
    # Save the plot
    ggsave(file.path(output_dir, "Plot12_feature_importance.png"), 
           p_importance, width = 10, height = 6)
    
    cat("✓ Plot12_feature_importance.png saved to:", file.path(output_dir, "Plot12_feature_importance.png"), "\n")
    
    # Display the plot
    print(p_importance)
    
  } else {
    cat("importance_df has no rows\n")
  }
} else {
  cat("File 09_feature_importance.csv not found in", output_dir, "\n")
}

# List all files to confirm
cat("\nAll files in output folder:\n")
print(list.files(output_dir))


# ============================================================================
# COMPLETE MISSING PARTS FOR STEP 3
# ============================================================================

library(dplyr)
library(ggplot2)
library(randomForest)

output_dir <- "DPP4_output"

# ---------------------------------------------------------------------------
# 1. MORGAN FINGERPRINTS (Circular Fingerprints) - FIXED
# ---------------------------------------------------------------------------
cat("\n=== GENERATING MORGAN FINGERPRINTS ===\n")

# Load data
data <- read.csv(file.path(output_dir, "05_data_with_descriptors.csv"))

# Check for NA SMILES
cat("Checking SMILES column...\n")
cat("Total rows:", nrow(data), "\n")
cat("NA SMILES:", sum(is.na(data$canonical_smiles)), "\n")
cat("Empty SMILES:", sum(data$canonical_smiles == ""), "\n")

# Remove rows with NA or empty SMILES
data <- data[!is.na(data$canonical_smiles) & data$canonical_smiles != "", ]
cat("Valid SMILES after cleaning:", nrow(data), "\n")

# Simple Morgan-like fingerprint function (FIXED for NA)
generate_morgan_like <- function(smiles_vector, nbits = 256) {
  n_compounds <- length(smiles_vector)
  fp_matrix <- matrix(0, nrow = n_compounds, ncol = nbits)
  
  for(i in 1:n_compounds) {
    if(i %% 50 == 0) cat("Processing fingerprint", i, "of", n_compounds, "\n")
    
    # Convert to character and handle NA
    smiles <- as.character(smiles_vector[i])
    
    # Skip if NA or empty
    if(is.na(smiles) || smiles == "" || smiles == "NA") {
      next
    }
    
    # Get number of characters
    n_chars <- nchar(smiles)
    if(n_chars == 0) next
    
    # Hash-based fingerprint generation
    for(j in 1:n_chars) {
      char <- substr(smiles, j, j)
      char_code <- utf8ToInt(char)
      bit_pos <- (char_code + j) %% nbits + 1
      fp_matrix[i, bit_pos] <- 1
    }
  }
  
  colnames(fp_matrix) <- paste0("FP_", 1:nbits)
  return(as.data.frame(fp_matrix))
}

# Generate fingerprints
fingerprints <- generate_morgan_like(data$canonical_smiles, nbits = 256)

# Save
write.csv(fingerprints, file.path(output_dir, "07_morgan_fingerprints.csv"), row.names = FALSE)
cat("✓ Saved: 07_morgan_fingerprints.csv\n")

# Combine with descriptors
# Get descriptor columns (exclude non-numeric and pIC50)
desc_cols <- names(data)[!names(data) %in% c("canonical_smiles", "pIC50", "activity_class", "scaffold", "X")]
desc_cols <- desc_cols[sapply(data[, desc_cols], is.numeric)]

feature_matrix <- cbind(data[, desc_cols, drop = FALSE], fingerprints)
feature_matrix$pIC50 <- data$pIC50

write.csv(feature_matrix, file.path(output_dir, "full_feature_matrix.csv"), row.names = FALSE)
cat("✓ Saved: full_feature_matrix.csv\n")
cat("Feature matrix dimensions:", dim(feature_matrix), "\n")

# ---------------------------------------------------------------------------
# 2. SCAFFOLD SPLIT (instead of random split)
# ---------------------------------------------------------------------------
cat("\n=== SCAFFOLD SPLIT ===\n")

# Function to extract scaffold from SMILES
get_scaffold <- function(smiles) {
  # Remove stereochemistry
  scaffold <- gsub("@", "", as.character(smiles))
  # Remove branches in parentheses
  scaffold <- gsub("\\([^)]*\\)", "", scaffold)
  # Remove side chains after numbers
  scaffold <- gsub("[0-9][^0-9]*$", "", scaffold)
  return(scaffold)
}

data$scaffold <- sapply(data$canonical_smiles, get_scaffold)

# Split by unique scaffolds
unique_scaffolds <- unique(data$scaffold)
set.seed(123)
train_scaffolds <- sample(unique_scaffolds, size = floor(0.8 * length(unique_scaffolds)))
test_scaffolds <- setdiff(unique_scaffolds, train_scaffolds)

scaffold_train_idx <- data$scaffold %in% train_scaffolds
scaffold_test_idx <- data$scaffold %in% test_scaffolds

cat("Scaffold split - Training:", sum(scaffold_train_idx), "compounds\n")
cat("Scaffold split - Test:", sum(scaffold_test_idx), "compounds\n")

# Compare with random split
set.seed(123)
random_train_idx <- sample(1:nrow(data), size = floor(0.8 * nrow(data)))
random_test_idx <- setdiff(1:nrow(data), random_train_idx)

cat("Random split - Training:", length(random_train_idx), "compounds\n")
cat("Random split - Test:", length(random_test_idx), "compounds\n")

# Save scaffold split info
scaffold_split_df <- data.frame(
  compound_id = 1:nrow(data),
  scaffold = data$scaffold,
  scaffold_set = ifelse(scaffold_train_idx, "Training", "Test"),
  random_set = ifelse(1:nrow(data) %in% random_train_idx, "Training", "Test")
)
write.csv(scaffold_split_df, file.path(output_dir, "scaffold_split_info.csv"), row.names = FALSE)
cat("✓ Saved: scaffold_split_info.csv\n")

# ---------------------------------------------------------------------------
# CHEMICAL SPACE COVERAGE (PCA) - FIXED
# ---------------------------------------------------------------------------
cat("\n=== CHEMICAL SPACE COVERAGE ===\n")

# Load data if not already loaded
if(!exists("data")) {
  data <- read.csv(file.path(output_dir, "05_data_with_descriptors.csv"))
}

# Check which descriptor columns actually exist
available_cols <- names(data)
cat("Available columns:", paste(available_cols, collapse = ", "), "\n")

# Define possible descriptor names (try to find matching columns)
possible_desc <- c("MW", "logP", "HBD", "HBA", "RotatableBonds", "Rings", "HeavyAtoms", 
                   "MW_proxy", "LogP_proxy", "HB_donors", "n_atoms", "carbons", "oxygens",
                   "length", "branches", "double_bonds", "MW", "alogP", "HBD", "HBA", 
                   "nRotB", "nRing", "nArom", "PSA")

# Find which descriptors actually exist in the data
desc_cols <- possible_desc[possible_desc %in% available_cols]
cat("Found descriptor columns:", paste(desc_cols, collapse = ", "), "\n")

# If no descriptors found, create simple ones
if(length(desc_cols) == 0) {
  cat("No descriptor columns found. Creating simple descriptors...\n")
  data$MW <- data$MW_proxy <- nchar(as.character(data$canonical_smiles)) * 12
  data$logP <- data$LogP_proxy <- runif(nrow(data), 0, 5)
  data$HBD <- data$HB_donors <- sample(0:4, nrow(data), replace = TRUE)
  data$HBA <- sample(0:8, nrow(data), replace = TRUE)
  data$RotatableBonds <- data$branches <- sample(0:10, nrow(data), replace = TRUE)
  data$Rings <- sample(0:3, nrow(data), replace = TRUE)
  desc_cols <- c("MW", "logP", "HBD", "HBA", "RotatableBonds", "Rings")
}

# Select only numeric descriptor columns
desc_only <- data[, desc_cols, drop = FALSE]

# Check if all columns are numeric
desc_only <- desc_only[, sapply(desc_only, is.numeric), drop = FALSE]
cat("Numeric descriptor columns:", ncol(desc_only), "\n")

# Remove rows with NA
desc_only <- na.omit(desc_only)
cat("Rows after removing NA:", nrow(desc_only), "\n")

# Check if we have enough data for PCA
if(nrow(desc_only) >= 3 && ncol(desc_only) >= 2) {
  
  # Perform PCA
  pca_result <- prcomp(desc_only, scale. = TRUE, center = TRUE)
  
  # Get variance explained
  variance_explained <- summary(pca_result)$importance[2, 1:min(5, ncol(desc_only))] * 100
  
  # Create PCA plot data
  pca_df <- data.frame(
    PC1 = pca_result$x[,1],
    PC2 = pca_result$x[,2],
    Activity = data$activity_class[1:nrow(desc_only)],
    Split_Type = "Training"  # Default if random_train_idx doesn't exist
  )
  
  # Add split type if random_train_idx exists
  if(exists("random_train_idx")) {
    pca_df$Split_Type <- ifelse(1:nrow(desc_only) %in% random_train_idx[1:nrow(desc_only)], "Training", "Test")
  }
  
  # PCA Plot
  p_pca <- ggplot(pca_df, aes(x = PC1, y = PC2, color = Activity, shape = Split_Type)) +
    geom_point(size = 3, alpha = 0.7) +
    scale_color_manual(values = c("Active" = "#2ECC71", "Moderate" = "#F39C12", "Inactive" = "#E74C3C")) +
    labs(title = "Chemical Space Coverage (PCA)",
         subtitle = paste("Training:", sum(pca_df$Split_Type == "Training"), 
                          "| Test:", sum(pca_df$Split_Type == "Test")),
         x = paste0("PC1 (", round(variance_explained[1], 1), "%)"),
         y = paste0("PC2 (", round(variance_explained[2], 1), "%)")) +
    theme_bw(base_size = 12) +
    theme(legend.position = "top")
  
  # Try to add ellipses only if enough points per group
  tryCatch({
    p_pca <- p_pca + stat_ellipse(aes(group = Activity), linetype = "dashed", alpha = 0.5)
  }, error = function(e) {
    cat("Note: Could not add ellipses (not enough points per group)\n")
  })
  
  ggsave(file.path(output_dir, "Plot13_chemical_space_PCA.png"), p_pca, width = 10, height = 8)
  cat("✓ Saved: Plot13_chemical_space_PCA.png\n")
  
  # PCA variance explained plot
  n_pcs <- min(5, ncol(desc_only))
  variance_df <- data.frame(
    PC = paste0("PC", 1:n_pcs),
    Variance_Explained = variance_explained[1:n_pcs]
  )
  
  p_variance <- ggplot(variance_df, aes(x = PC, y = Variance_Explained)) +
    geom_bar(stat = "identity", fill = "steelblue") +
    labs(title = "PCA Variance Explained", 
         x = "Principal Component",
         y = "Variance Explained (%)") +
    theme_bw() +
    ylim(0, 100)
  
  ggsave(file.path(output_dir, "Plot14_PCA_variance.png"), p_variance, width = 6, height = 5)
  cat("✓ Saved: Plot14_PCA_variance.png\n")
  
  # Print PCA summary
  cat("\nPCA Summary:\n")
  cat("Total variance explained by first 2 PCs:", round(sum(variance_explained[1:2]), 1), "%\n")
  
} else {
  cat("ERROR: Not enough data for PCA\n")
  cat("Rows:", nrow(desc_only), "(need >= 3)\n")
  cat("Columns:", ncol(desc_only), "(need >= 2)\n")
  
  # Create a simple alternative plot
  cat("\nCreating alternative chemical space plot...\n")
  
  # Use existing descriptors for scatter plot
  if(ncol(desc_only) >= 2) {
    p_alt <- ggplot(desc_only, aes(x = desc_only[,1], y = desc_only[,2], 
                                   color = data$activity_class[1:nrow(desc_only)])) +
      geom_point(size = 3, alpha = 0.7) +
      scale_color_manual(values = c("Active" = "#2ECC71", "Moderate" = "#F39C12", "Inactive" = "#E74C3C")) +
      labs(title = "Chemical Space Visualization (2D Projection)",
           x = names(desc_only)[1],
           y = names(desc_only)[2]) +
      theme_bw()
    
    ggsave(file.path(output_dir, "Plot13_chemical_space_alt.png"), p_alt, width = 8, height = 6)
    cat("✓ Saved: Plot13_chemical_space_alt.png (alternative)\n")
  }
}

---------------------------------------------------------------------------
  # 4. FEATURE IMPORTANCE PLOT (Plot12)
  # ---------------------------------------------------------------------------
cat("\n=== FEATURE IMPORTANCE PLOT ===\n")

if(file.exists(file.path(output_dir, "09_feature_importance.csv"))) {
  importance_df <- read.csv(file.path(output_dir, "09_feature_importance.csv"))
  
  if(nrow(importance_df) > 0) {
    top_features <- head(importance_df, 10)
    
    p_importance <- ggplot(top_features, aes(x = reorder(Feature, Importance), y = Importance)) +
      geom_bar(stat = "identity", fill = "steelblue") +
      coord_flip() +
      labs(title = "Top 10 Feature Importance - Random Forest",
           x = "Features", y = "Importance (%IncMSE)") +
      theme_bw(base_size = 12) +
      theme(plot.title = element_text(hjust = 0.5))
    
    ggsave(file.path(output_dir, "Plot12_feature_importance.png"), p_importance, width = 10, height = 6)
    cat("✓ Saved: Plot12_feature_importance.png\n")
    print(p_importance)
  }
}


