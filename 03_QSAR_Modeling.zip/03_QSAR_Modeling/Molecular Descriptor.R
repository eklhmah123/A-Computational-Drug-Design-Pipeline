# ====== COMPLETE WORKING CODE - COPY ALL OF THIS ======

# STEP 1: Load libraries
library(tidyverse)
library(dplyr)
library(ggplot2)
library(readr)

# STEP 2: Set working directory
setwd("C:/Users/Sarim/Downloads/")

# STEP 3: Check if file exists
file.exists("dpp4_real_data.c")

# STEP 4: Read and display first 20 lines
readLines("dpp4_real_data.c", n = 20)

# STEP 5: Read the data
data <- read.csv("dpp4_real_data.c", header = TRUE, fill = TRUE)

# STEP 6: View the data
View(data)

# STEP 7: See structure
str(data)

# STEP 8: Summary statistics
summary(data)

# STEP 1: Check what users exist on your computer
list.dirs("C:/Users/")

# STEP 2: Based on your earlier messages, your username might be "Saram" not "sarim"
# Try this instead:
setwd("C:/Users/Saram/Downloads/")

cat("\n======= STEP 4: READING FILE =======\n")
raw_data <- readLines("dpp4_real_data.c", warn = FALSE)
cat("Total lines in file:", length(raw_data), "\n")

# -----------------------------------------------------------------------------
# 1.  CREATE OUTPUT FOLDER
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# 2.  LOAD RAW DATA - FIXED FOR .c FILE
# -----------------------------------------------------------------------------
cat("=== STEP 2A: LOADING RAW DATASET ===\n")

# Auto-detect file location for .c file
possible_paths <- c(
  "dpp4_real_data.c",
  "dpp4_real_data.csv",
  file.path(Sys.getenv("USERPROFILE"), "Downloads", "dpp4_real_data.c"),
  file.path(Sys.getenv("USERPROFILE"), "Downloads", "dpp4_real_data.csv"),
  file.path(Sys.getenv("HOME"), "Downloads", "dpp4_real_data.c"),
  file.path("C:/Users/Saram/Downloads", "dpp4_real_data.c"),
  file.path("C:/Users/Sarim/Downloads", "dpp4_real_data.c"),
  file.path("C:/Users/Saram/Downloads", "dpp4_real_data.csv"),
  file.path("C:/Users/Sarim/Downloads", "dpp4_real_data.csv")
)

found_path <- NULL
for (p in possible_paths) {
  if (file.exists(p)) { 
    found_path <- p
    break
  }
}

# If still not found, search the entire Downloads folder
if (is.null(found_path)) {
  cat("\nSearching entire Downloads folder for any file with 'dpp4' in name...\n")
  downloads_folder <- file.path(Sys.getenv("USERPROFILE"), "Downloads")
  if(dir.exists(downloads_folder)) {
    all_files <- list.files(downloads_folder, pattern = "dpp4", full.names = TRUE, recursive = TRUE)
    if(length(all_files) > 0) {
      found_path <- all_files[1]
      cat("Found file:", found_path, "\n")
    }
  }
}

if (is.null(found_path)) {
  # Last resort - use file chooser
  cat("\nPlease select your dpp4_real_data.c file manually...\n")
  found_path <- file.choose()
}

cat("\n✓ Found file at:", found_path, "\n")

# Read the file - handle potential format issues
raw_df <- tryCatch({
  read_csv(found_path, show_col_types = FALSE)
}, error = function(e) {
  cat("Error reading as CSV, trying as tab-delimited...\n")
  read.delim(found_path, header = TRUE, fill = TRUE, stringsAsFactors = FALSE)
})

raw_n  <- nrow(raw_df)
cat("\nRaw dataset shape  :", raw_n, "rows x", ncol(raw_df), "columns\n")

# Check column names to understand structure
cat("\nColumn names in your data:\n")
print(names(raw_df))

# Try to identify standard columns (based on your data structure)
if(!"standard_type" %in% names(raw_df)) {
  cat("\nWARNING: Column 'standard_type' not found. Looking for similar columns...\n")
  print(grep("type|activity", names(raw_df), value = TRUE, ignore.case = TRUE))
}

# Save raw data as-is for record
write.csv(raw_df, file.path(output_dir, "01_raw_dataset.csv"), row.names = FALSE)
cat("Saved: 01_raw_dataset.csv\n\n")


# -----------------------------------------------------------------------------
# 3.  SELECT COLUMNS WE NEED (ADAPTED TO YOUR DATA STRUCTURE)
# -----------------------------------------------------------------------------

# Find available columns
available_cols <- names(raw_df)

# Map expected columns to available ones
col_mapping <- list(
  molecule_chembl_id = grep("molecule|chembl", available_cols, value = TRUE, ignore.case = TRUE)[1],
  canonical_smiles = grep("smiles|canonical", available_cols, value = TRUE, ignore.case = TRUE)[1],
  standard_type = grep("type|activity_typ", available_cols, value = TRUE, ignore.case = TRUE)[1],
  standard_value = grep("value|pchembl|standard", available_cols, value = TRUE, ignore.case = TRUE)[1],
  pchembl_value = grep("pchembl", available_cols, value = TRUE, ignore.case = TRUE)[1]
)

cat("\nColumn mapping:\n")
print(col_mapping)

# Select available columns
selected_cols <- na.omit(unlist(col_mapping))
if(length(selected_cols) > 0) {
  df <- raw_df %>% select(all_of(selected_cols))
} else {
  # If no mapping works, just take first 5 columns
  df <- raw_df[, 1:min(5, ncol(raw_df))]
}

cat("\nWorking with", ncol(df), "columns\n")


# -----------------------------------------------------------------------------
# 4.  DATA CLEANING - EXTRACT NUMERIC VALUES
# -----------------------------------------------------------------------------
cat("\n=== STEP 2B: DATA CLEANING ===\n")

# If standard_value is character, extract numbers
if("standard_value" %in% names(df) && is.character(df$standard_value)) {
  df$standard_value <- as.numeric(gsub("[^0-9.-]", "", df$standard_value))
}

# If pchembl_value exists, use it
if("pchembl_value" %in% names(df)) {
  df$pchembl_clean <- as.numeric(gsub("[^0-9.-]", "", df$pchembl_value))
  cat("Using pchembl_value column\n")
} else {
  # Create pIC50 from standard_value if available
  if("standard_value" %in% names(df) && is.numeric(df$standard_value)) {
    df$pchembl_clean <- 9 - log10(df$standard_value)
    cat("Calculated pIC50 from standard_value\n")
  }
}

# Remove NA values
before <- nrow(df)
df <- df %>% filter(!is.na(pchembl_clean))
cat(sprintf("Removed %d rows with missing values\n", before - nrow(df)))

# Remove outliers (optional)
before <- nrow(df)
df <- df %>% filter(pchembl_clean > 0 & pchembl_clean < 15)
cat(sprintf("Removed %d outlier rows\n", before - nrow(df)))


# -----------------------------------------------------------------------------
# 5.  CREATE FINAL DATASET
# -----------------------------------------------------------------------------
final_df <- df %>%
  mutate(
    compound_id = 1:n(),
    activity_class = case_when(
      pchembl_clean >= 7.0 ~ "Active",
      pchembl_clean >= 6.0 ~ "Moderate",
      TRUE ~ "Inactive"
    ),
    active_binary = if_else(pchembl_clean >= 6.0, 1, 0)
  )

cat("\n=== FINAL DATASET SUMMARY ===\n")
cat("Total compounds:", nrow(final_df), "\n")
cat("Activity distribution:\n")
print(table(final_df$activity_class))

# -----------------------------------------------------------------------------
# 6.  SAVE RESULTS
# -----------------------------------------------------------------------------
write.csv(final_df, file.path(output_dir, "02_curated_dataset.csv"), row.names = FALSE)
write.csv(df, file.path(output_dir, "03_cleaned_data.csv"), row.names = FALSE)

cat("\n✓ Saved: 02_curated_dataset.csv\n")
cat("✓ Saved: 03_cleaned_data.csv\n")


# -----------------------------------------------------------------------------
# 7.  GENERATE BASIC PLOTS
# -----------------------------------------------------------------------------




